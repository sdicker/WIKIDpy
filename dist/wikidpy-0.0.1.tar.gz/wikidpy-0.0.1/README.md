# WIKIDpy
This will be the MIDAS pipeline re-written in python
- extensive use of GBO's new python pipeline for things such as the timestreams to maps is planned
- It is intended to be backwards and forwards compatible with WIKID, and MUSTANG2 (and maybe even MUSTANG!)
To Do:
- basic routines to read in data and save it to SD fits format.  Includes quadrant detector etc.
- Extend this to save it in format for OOF
- cmsub, pca etc
- Calibration pipeline
- gui