"""Reads a MUSTANG2 scan from"""

def readscan.py:
    pass
